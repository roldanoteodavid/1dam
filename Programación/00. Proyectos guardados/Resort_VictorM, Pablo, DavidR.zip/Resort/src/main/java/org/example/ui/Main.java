package org.example.ui;

import org.example.dao.DaoHotelFicheros;

import java.io.IOException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        MainHotel main = new MainHotel();
        main.main();
    }
}