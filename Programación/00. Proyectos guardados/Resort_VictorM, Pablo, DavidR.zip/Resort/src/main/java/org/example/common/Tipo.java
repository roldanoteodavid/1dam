package org.example.common;

public enum Tipo {
    quad, doble, king;
}
