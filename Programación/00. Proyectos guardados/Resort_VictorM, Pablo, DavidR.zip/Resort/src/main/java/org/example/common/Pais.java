package org.example.common;

public enum Pais {
    France, Francia, França, Frankreich, Frankrijk, Frankrike, Frankrig, Ranska, Франция, فرنسا, 法国, フランス, 프랑스;
}