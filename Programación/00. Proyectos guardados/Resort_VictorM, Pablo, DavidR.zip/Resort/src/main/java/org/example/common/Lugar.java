package org.example.common;

public enum Lugar {
    gimnasio, piscina, rocodromo, playa;
}
