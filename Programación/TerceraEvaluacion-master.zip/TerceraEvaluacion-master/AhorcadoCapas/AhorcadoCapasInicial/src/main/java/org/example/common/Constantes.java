package org.example.common;

public class Constantes {
    public static final String FICHERO = "elementos";
    public static final String FICHEROB = "copiaSeguridad";
    public static final String MENU = "Introduce opción: ";
    public static final String OPCION1 ="Listar Diccionario Ordenado";
    public static final String OPCION2 = "Insertar un elemento al diccionario";
    public static final String OPCION3 = "Modificar algún campo de un elemento del diccionario";
    public static final String OPCION4 = "Eliminar un elemento del diccionario";
}
