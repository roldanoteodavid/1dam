package org.example.common;

public enum Categoria {
    accion, comedia, miedo, pokemon; //lo que queráis series, música, juegos, etc.
}
