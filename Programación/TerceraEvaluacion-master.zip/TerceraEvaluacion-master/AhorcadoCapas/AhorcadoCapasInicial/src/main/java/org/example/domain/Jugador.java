package org.example.domain;

public class Jugador {
    //opcional nombre,
}
